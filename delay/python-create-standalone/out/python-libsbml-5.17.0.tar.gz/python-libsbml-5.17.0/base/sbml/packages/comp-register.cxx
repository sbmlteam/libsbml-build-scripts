
#ifdef USE_COMP
CompExtension::init();
#endif	

