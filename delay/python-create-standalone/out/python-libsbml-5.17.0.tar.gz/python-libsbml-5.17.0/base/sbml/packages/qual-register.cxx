
#ifdef USE_QUAL
QualExtension::init();
#endif	

