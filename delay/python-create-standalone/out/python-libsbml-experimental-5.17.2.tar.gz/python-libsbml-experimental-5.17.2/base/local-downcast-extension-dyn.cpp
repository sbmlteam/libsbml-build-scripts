#ifdef USE_DYN
if (pkgName == "dyn")
{
  return SWIGTYPE_p_DynExtension;
}
#endif // USE_DYN 

