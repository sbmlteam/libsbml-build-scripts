

#ifdef USE_COMP
if (pkgName == "comp")
{		
	return SWIGTYPE_p_SBMLExtensionNamespacesT_CompExtension_t;
}
#endif	

