
#ifdef USE_LAYOUT
	// if (conName == "converter")
	//	return SWIGTYPE_p_converterType;
#endif
