
#ifdef USE_ARRAYS
ArraysExtension::init();
#endif	

