
#ifdef USE_LAYOUT
if (pkgName == "layout")
{		
	return SWIGTYPE_p_SBMLExtensionNamespacesT_LayoutExtension_t;
}
#endif

