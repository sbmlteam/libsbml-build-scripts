
#ifdef USE_LAYOUT
if (pkgName == "layout")
{		
	return SWIGTYPE_p_LayoutExtension;
}
#endif
