#ifdef USE_REQUIREDELEMENTS
if (pkgName == "req")
{
  return SWIGTYPE_p_SBMLExtensionNamespacesT_ReqExtension_t;
}
#endif // USE_REQUIREDELEMENTS 

