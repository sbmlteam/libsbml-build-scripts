#ifdef USE_REQUIREDELEMENTS
if (pkgName == "req")
{
  return SWIGTYPE_p_ReqExtension;
}
#endif // USE_REQUIREDELEMENTS 

