
#ifdef USE_ARRAYS
if (pkgName == "arrays")
{		
	return SWIGTYPE_p_ArraysASTPlugin;
}
#endif	

