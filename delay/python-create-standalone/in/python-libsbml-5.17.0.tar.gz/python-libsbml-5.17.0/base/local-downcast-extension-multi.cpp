#ifdef USE_MULTI
if (pkgName == "multi")
{
  return SWIGTYPE_p_MultiExtension;
}
#endif // USE_MULTI 

