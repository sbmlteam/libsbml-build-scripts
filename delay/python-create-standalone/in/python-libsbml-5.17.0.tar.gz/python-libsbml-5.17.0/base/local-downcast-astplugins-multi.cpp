#ifdef USE_MULTI
if (pkgName == "multi")
{
  return SWIGTYPE_p_MultiASTPlugin;
}
#endif // USE_MULTI 

