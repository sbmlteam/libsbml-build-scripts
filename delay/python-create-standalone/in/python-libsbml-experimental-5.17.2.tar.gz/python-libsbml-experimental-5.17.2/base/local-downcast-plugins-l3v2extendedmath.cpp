#ifdef USE_L3V2EXTENDEDMATH
if (pkgName == "l3v2extendedmath")
{
  if(sb->getTypeCode() == SBML_DOCUMENT)
  {
    return SWIGTYPE_p_L3v2extendedmathSBMLDocumentPlugin;
  }
}

#endif // USE_FBC 

