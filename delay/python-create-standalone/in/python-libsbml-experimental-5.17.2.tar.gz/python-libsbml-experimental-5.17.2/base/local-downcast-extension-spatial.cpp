#ifdef USE_SPATIAL
if (pkgName == "spatial")
{
  return SWIGTYPE_p_SpatialExtension;
}
#endif // USE_SPATIAL 

