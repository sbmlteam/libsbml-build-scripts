#ifdef USE_SPATIAL
if (pkgName == "spatial")
{
  return SWIGTYPE_p_SBMLExtensionNamespacesT_SpatialExtension_t;
}
#endif // USE_SPATIAL 

