
#ifdef USE_L3V2EXTENDEDMATH
if (pkgName == "l3v2extendedmath")
{		
	return SWIGTYPE_p_L3v2extendedmathASTPlugin;
}
#endif	

