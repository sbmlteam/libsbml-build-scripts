
#ifdef USE_DISTRIB
if (pkgName == "distrib")
{		
	return SWIGTYPE_p_DistribASTPlugin;
}
#endif	

